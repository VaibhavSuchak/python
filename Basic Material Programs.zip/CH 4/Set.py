'''
# using default set and curly braces

week = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}    
print(week)    
print(type(week))    
print("looping set elements ")    
for i in week:    
    print(i) 
'''

# # using set method

# week = set(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])    
# print(week)    
# print(type(week))    
# print("looping through the set elements ... ")    
# for i in week:    
#     print(i)  

'''
# empty set by using curly braces
set3 = {}  
print(type(set3))  
  
# Empty set using set() function  
set4 = set()  
print(type(set4))  
'''
# # duplicate value not allowed in set automatically remove duplication
# s = {1,2,3,4,4,5,6,6,6,7,8,9,9,10}  
# print("Return set with unique elements:",s)  

'''
# add() method use
day = set(["Monday","Tuesday", "Wednusday", "Thursday"])    
print("\n original set ")    
print(day)    
print("\n Adding other Days in set...");    
day.add("Friday");    
day.add ("Saturday");    
print("\n Printing the updated set...");    
print(day)    
print("\n looping through the set")    
for i in day:    
    print(i)  
'''

# # using update() method

# day = set(["Monday","Tuesday", "Wednusday", "Thursday"])    
# print("\n original set  ")    
# print(day)    
# print("\n updating the set ")    
# day.update(["Friday","Saturday","Sunday"]);    
# print("\n printing the updated set ")     
# print(day);  

'''
# Removing items from set
day = set(["Monday","Tuesday", "Wednusday", "Thursday", "Friday"])    
print("\n original set")    
print(day)    
print("\n Removing some months from the set");    
day.discard("Tuesday");    
day.discard("Friday");    
print("\n Printing the set after updatation");    
print(day)    
print("\nlooping through the set elements ... ")    
for i in day:    
    print(i)  
'''

# day = set(["Monday","Tuesday", "Wednusday", "Thursday", "Friday"])    
# print("\nprinting the set")    
# print(day)    
# print("\n Removing all items from set");    
# day.clear()    
# print("\n Updated set")    
# print(day)  

# Days1 = {"Monday",  "Tuesday", "Wednesday", "Thursday"}    
# Days2 = {"Monday", "Tuesday"}    
# Days3 = {"Monday", "Tuesday", "Friday"}    
    


''' ------- Set Comparision ------- '''   

Days1 = {"Monday",  "Tuesday", "Wednesday", "Thursday"}    
Days2 = {"Monday", "Tuesday"}    
Days3 = {"Monday", "Tuesday", "Friday"}    
#Days1 is the superset of Days2 hence it will print true.     
print (Days1>Days2)     
    
#prints false since Days1 is not the subset of Days2     
print (Days1<Days2)    
    
#prints false since Days2 and Days3 are not equivalent     
print (Days2 == Days3)   