'''
Dict = {}       
print("Empty Dictionary: ")       
print(Dict)       
   
      
# Using dict() method       
Dict = dict({1: 'Hcl', 2: 'WIPRO', 3:'Facebook'})       
print("\nCreate Dictionary by using  dict(): ")       
print(Dict)       
      
# with each item as a Pair       
Dict = dict([(4, 'Rinku'), (2, "Singh")])       
print("\nDictionary with each item as a pair: ")       
print(Dict)       
'''

# Employee = {"Name": "Aman", "Age": 20, "salary":55000,"Company":"TCS"}      
# print(type(Employee))      
# print("printing Employee data using key.... ")      
# print("Name : %s" %Employee["Name"])      
# print("Age : %d" %Employee["Age"])      
# print("Salary : %d" %Employee["salary"])      
# print("Company : %s" %Employee["Company"])  

'''
Employee = {"Name": "Aman", "Age": 20, "salary":55000,"Company":"TCS"}      
print(type(Employee))      
print("printing Employee data .... ")        
print(Employee)        
print("Enter the details of the new employee....");        
Employee["Name"] = input("Name: ");        
Employee["Age"] = int(input("Age: "));        
Employee["salary"] = int(input("Salary: "));        
Employee["Company"] = input("Company:");        
print("printing the new data");        
print(Employee)   
''' 


# Dict = {}       
# print("Empty Dictionary: ")       
# print(Dict)       
 
# # Adding elements to dictionary one at a time       
# Dict[0] = 'Atmiya'      
# Dict[1] = 'Rk'      
# Dict[2] = 'Darshan'      
# print("\nDictionary after adding 3 elements: ")       
# print(Dict)       

# # Adding set of values with 1 key       
# # The Emp_ages doesn't exist to dictionary  so it add the key value in our dictionary     
# Dict['Students'] = 200, 203, 204      
# print("\nDictionary after adding 3 elements: ")       
# print(Dict)       
        
# # Updating existing Key's Value       
# Dict[1] = 'Marwadi'      
# print("\n Updated key value: ")       
# print(Dict)    

'''
Employee = {"Name": "Aman", "Age": 30, "salary":45000,"Company":"Reliance"}         
print(type(Employee))        
print("printing Employee data .... ")        
print(Employee)        
print("Deleting employee data")         
del Employee["Name"]        
del Employee["Company"]        
print("printing the modified information ")        
print(Employee)        
print("Deleting dictionary: Employee");        
del Employee        
print("Lets try to print dictionary Employee ");        
print(Employee)       

 
''' 

# In Built functions of the python.
dict = {1: "Ac", 2: "Bc", 3: "Cc", 4: "Dc"}  
print(dict.values())

