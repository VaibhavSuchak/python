for i in range(10):
    print(i, end=" ")

D_Stream = {"Computer": 120, "Civil": 32, "Electrical":40,"Mechanical":"33"}        
print(type(D_Stream))        
print("...... Diploma Course ...... ")        
print(D_Stream)   
