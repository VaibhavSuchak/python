# Content of List Dir

import os 
print(os.listdir())