# Write a program to print Poem in python.

print('''Twinkle, Twinkle, Little star,
How I Wonder what you are!
Up above the world so high,
Like a dimond in the sky.''') 

