
num = 10

if num > 1:
    for i in range(2, int(num/2)+1):
        if (num % i) == 0:
            print(num, "is not a prime number")
        break
    else:
        print(num,"Prime Number")
else:
    print(num," Not Prime Number")