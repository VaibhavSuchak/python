# Single line comment
''' Multi line comment 
    just for reference
'''
print("Hello World")



# 1st Pattern
for i in range(1,4):
    for l in range(i,3):
        print(" ",end="")
    for j in range(1,i+1):
        print(i," ",end="")
    print("\r")
'''

# 2nd Pattern
for i in range(1,4):
    for l in range(i,3):
        print(" ",end="")
    for j in range(1,i+1):
        print("*",end="")
    print("\r")

    # 3rd Pattern
for i in range(1,4):
    for l in range(i,3):
        print(" ",end="")
    for j in range(1,i+1):
        print(j,end="")
    print("\r")  
   

'''
 