lower_value = int(input("Please enter lower value for prime number"))
upper_value = int(input("Please enter upper value for prime number"))

print("the prime number range are")

for number in range(lower_value,upper_value+1):
    if number>1:
        for i in range(2,number):
            if(number%i)==0:
                break
        else:
            print(number)