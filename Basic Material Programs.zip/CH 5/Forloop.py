# If you Want to do loop its necessary to use Range() for numeric looping 

range(5)
# Start = 0
# Condition < 5
# Increment = 1    0,1,2,3,4

range(1,6)
# Start = 1
# Condition < 6
# Increment = 1     1,2,3,4,5

range(1,6,2)
# Start = 1
# Condition < 6
# Increment = 2     1,3,5

for i in range(5):
    print(i, " " , end="")
print()
for i in range(1,6):
    print(i," ",end="")
print()
for i in range(1,6,2):
    print(i," ", end="")
print()


# Example of printing Table of 3

for i in range(1,11):
    print("3 * ",i ,"=" ,i * 3)