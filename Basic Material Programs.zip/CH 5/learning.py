l1=["mca","diplo","be"]
print(l1)
print(l1[0:2])
for x in l1:
    print(x)

