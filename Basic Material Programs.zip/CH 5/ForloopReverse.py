range(10,0,-1)
# Start = 10
# Condition < 0
# Decrement = 1    used for recversing the given input

# Example
for i in range(10,0,-1):
    print(i," ", end="")
print()

for i in range(10,0,-2):
    print(i," ", end="")