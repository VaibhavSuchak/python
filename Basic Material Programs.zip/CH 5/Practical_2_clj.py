# string=input(("Enter Letter:"))
# if(string==string[::-1]):
#     print("Letter is Palindrome")
# else:
#     print("Letter is not palindrome")


print("enter date in original format DD/MM/YYYY")
date = input("Enter the Date:")
date = date.split("/")
print("Date in format MM/DD/YYYY: %s %s %s" % (date[1], date[0], date[2]))
