'''
Iterable = __iter__()  or __getitem__()   method used then it provide Iterator
Iterator = __next__() 
Iteration = it is the process of doind iterrat 


Iterate means Travers of string, list etc

'''

# Generator is Iterator by which you can iterate only once

def gen(n):
    for i in range(n):
        yield i 


g = gen(3)
print(g)
# print(g.__next__())
# print(g.__next__())
# print(g.__next__())

for i in g:
    print(i)