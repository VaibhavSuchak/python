a = 34 
b = "kishan' k"   # Use this if you have single quotes in your strings
# b = 'kishan" k'
print(a, b)
# print(type(b)) 


n=int(input("Enter the Decimal Number"))
print(bin(n))
print(oct(n))
print(hex(n))