n=int(input("Enter the Decimal Number"))
print(bin(n))
print(oct(n))
print(hex(n))