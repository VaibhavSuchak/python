'''Ordered sequence of items and it it is most used datatype define by []'''

l = [1, 5, "kk", 5.5, "Atmiya"]     # simple list
l[-1]= "abc"            # updating the list
print(l,type(l))     #display the type of l

'''Tuple: Ordered sequence of items defined by () and tuple is faster then list, tuple always have more then 1 value'''
t=(5, "kishan", 1+2j)
print(t,type(t))
t = (90)
print(t,type(t))



'''Dictionary: unordered collection of key value pairs, defined by {}, every item is in pair example key:value, mostly used in case of database'''
'''easily data insert, update and delete'''

d = {
    "stream" : "Computer",
    "Semester" : "secound",
    "name" : "Kishan"
    
}
print(d["stream"])
print(d,type(d))

''' Set:it is unordered collection of items,  no duplicate allow so every set element is unique and also immutable(cant be changed) '''
'''Values are not get by index number or not updated '''
s = {1,2,3,4,5}
print(s,type(s))