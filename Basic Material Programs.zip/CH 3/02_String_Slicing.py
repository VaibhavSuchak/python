'''

greeting = "Good Morning, "
name = "kishan"
print(type(name))
print(greeting + name)   # String Concatination operation 

name = "kishan"
# print(name[1])    # access element using index

# SLICING of String 

# print(name[2:4]) 

# negetive indexing is used when user dont know about actual length of string and they need to access last char of string then you call last character as a -1
print(name[:3])   # it is same as name[0:3]


'''
name = "Atmiya university"
d = name[0::3]     # skip the two characters 
print(d)