# Making of Letter Format

letter = '''Dear <|Name|>,
Congratulations, we are happy to inform you that,
You are selected!

Date: <|Date|>'''

name = input("Enter your name \n")
date = input("Enter your date \n")
letter = letter.replace("<|Name|>",name)
letter = letter.replace("<|Date|>",date)

print(letter)
