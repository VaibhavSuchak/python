st = "kk h hj j kj   jhfj  khj jl jl j  kjl kl lk j l"
doubleSpaces = st.find(" ")
print(doubleSpaces)
st = st.replace("  "," ")
print(st)