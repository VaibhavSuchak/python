story = "python is a very easy language as compare to other languages"

# String Functions
print(len(story))
print(story.endswith("es"))
print(story.count("e"))   # Counting the letters/words from input string
print(story.capitalize()) # make first word capital
print(story.find("as"))   # find the given words
print(story.replace("easy" , "kishan"))   # Replacing the string 
print() 