'''
CONDITIONAL STATEMENTS
1. If 
2. If Else
3. If Elif Else
'''

'''Syntax
if[conditional expression]:   Colon represent starting of statement
    [statements to execute]
'''
# if condition is true then ans displayed otherwise ans not displayed

a = int(input("Enter the value ")) 
if a %2 == 0:
    print("even numbers",a)

 
'''Syntax
if[conditional expression]:   
    [statements to execute]
else:
    [Alternet Statement]    
    
'''

a = int(input("Enter the value ")) 
if a %2 == 0:
    print("even numbers",a)
else:
    print("odd number")


'''Syntax of If Elif Else 
it is used when user need to provide multiple conditions

if[conditiona #1]:  
    [statements #1]
elif[condition #2]:
    [Statement #2]    
elif[condition #3]:
    [Statement #3]

else:
    [Statement when if and elif are represent False Value]        
    
'''

pr = int(input("Enter the value: "))
if pr>=60:
    print("First Class")
elif pr>=50:
    print("Second Class")
elif pr>=35:
    print("Pass")
else:
    print("Fail")            