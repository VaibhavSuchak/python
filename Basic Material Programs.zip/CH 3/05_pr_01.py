# PRACTICA SET 

name = input("Enter Name ")
print("Good Noon, "+name)

