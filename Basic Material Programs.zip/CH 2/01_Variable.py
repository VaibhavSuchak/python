
a = '''Kishan'''
# a = 'Kishan'
# a = "Kishan"
b = 345
c = 45.80 
d = True

# printing the Variables
print(a)
print(b)
print(c)
print(d)
 
# Printing the type of Variables
print(type(a))
print(type(b))
print(type(c))
print(type(d))
