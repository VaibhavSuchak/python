'''Practice set practical - 2'''
a = 27
b = 5

print("The remainder when a is divided by b is:", a % b)