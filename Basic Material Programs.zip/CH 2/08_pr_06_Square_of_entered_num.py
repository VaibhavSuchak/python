'''Practice set practical - 5'''
''' Take a value from user and print SQUARE of it'''


a = input("Enter the element:")
a = int(a)
square = (a * a)
print("Square of given number is: ",square)