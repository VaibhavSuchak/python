# Defination of input function
''' Input Function allow the user to take input from the keyboard as a string '''

a = input("Enter your numbers:")
a = int(a) # for converting a to an integer (if it is possible)
print(type(a))  # for checking type of a