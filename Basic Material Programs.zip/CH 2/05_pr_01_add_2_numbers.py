'''Practice set practical - 1'''
a = 25
b = 5
print("The sum of a and b is:", a + b)