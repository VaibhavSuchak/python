''' Program to represent typecasting in python '''
a = "3545"
a = int(a)    # By using this user can convert string datatype into integer
#print(type(a))  # identifying the type of a is string
print(a + 5)
